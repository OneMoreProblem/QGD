#include "extendedFaceStencil.H"
#include "polyMesh.H"
#include "fvMesh.H"
#include "word.H"
#include "IOstream.H"
#include "wedgeFvPatch.H"
#include "symmetryPlaneFvPatch.H"
#include "symmetryFvPatch.H"
#include "emptyFvPatch.H"
#include "Ostream.H"
#include <HashTable.H>

// constructors
Foam::extendedFaceStencil::extendedFaceStencil(const IOobject& io, const bool isTime)
:
    regIOobject(io, isTime),
    mesh_(refCast<const fvMesh>(io.db()))
{
    findNeighbours();
    calculateWeights();
}


Foam::extendedFaceStencil::extendedFaceStencil(const regIOobject& rio)
:
    regIOobject(rio),
    mesh_(refCast<const fvMesh>(rio.db()))
{
    findNeighbours();
    calculateWeights();
}

Foam::extendedFaceStencil::extendedFaceStencil(const regIOobject& rio, bool registerCopy)
:
    regIOobject(rio, registerCopy),
    mesh_(refCast<const fvMesh>(rio.db()))
{
    findNeighbours();
    calculateWeights();
}

Foam::extendedFaceStencil::~extendedFaceStencil()
{
}

void Foam::extendedFaceStencil::rename(const word& newName)
{
};

bool Foam::extendedFaceStencil::readData(Istream&)
{
  return false;
};

bool Foam::extendedFaceStencil::read()
{
  return false;
};

bool Foam::extendedFaceStencil::modified()  const
{
  return false;
};

bool Foam::extendedFaceStencil::readIfModified()
{
  return false;
};

bool Foam::extendedFaceStencil::writeData(Ostream&) const
{
  return false;
};

bool Foam::extendedFaceStencil::writeObject
(
    IOstream::streamFormat,
    IOstream::versionNumber,
    IOstream::compressionType
)  const
{
  return false;
};

bool Foam::extendedFaceStencil::write()  const
{
  return false;
};

//- Calculate gradient of volume vector field on the faces.
//
// \param iVF      Internal vector field.
//                 Allowable values: constant reference to the volVectorField.
//
// \return         Gradient of iVF (tensor field) which was computed on the faces of mesh.
tmp<surfaceTensorField> Foam::extendedFaceStencil::faceVectorGrad(const volVectorField& iVF, const surfaceVectorField& sVF)
{
    tmp<surfaceTensorField> tgradIVF(0*fvc::snGrad(iVF) * mesh_.Sf() / mesh_.magSf());
    scalarField tField(sVF.primitiveField().size(),0.0); 
    surfaceTensorField& gradIVF = tgradIVF.ref();


    faceScalarDer(iVF.primitiveField().component(0),sVF.primitiveField().component(0),0,tField);
    gradIVF.primitiveFieldRef().replace(0,tField);

    faceScalarDer(iVF.primitiveField().component(0),sVF.primitiveField().component(0),1,tField);
    gradIVF.primitiveFieldRef().replace(3,tField);

    faceScalarDer(iVF.primitiveField().component(0),sVF.primitiveField().component(0),2,tField);
    gradIVF.primitiveFieldRef().replace(6,tField);

    faceScalarDer(iVF.primitiveField().component(1),sVF.primitiveField().component(1),0,tField);
    gradIVF.primitiveFieldRef().replace(1,tField);

    faceScalarDer(iVF.primitiveField().component(1),sVF.primitiveField().component(1),1,tField);
    gradIVF.primitiveFieldRef().replace(4,tField);

    faceScalarDer(iVF.primitiveField().component(1),sVF.primitiveField().component(1),2,tField);
    gradIVF.primitiveFieldRef().replace(7,tField);

    faceScalarDer(iVF.primitiveField().component(2),sVF.primitiveField().component(2),0,tField);
    gradIVF.primitiveFieldRef().replace(2,tField);

    faceScalarDer(iVF.primitiveField().component(2),sVF.primitiveField().component(2),1,tField);
    gradIVF.primitiveFieldRef().replace(5,tField);

    faceScalarDer(iVF.primitiveField().component(2),sVF.primitiveField().component(2),2,tField);
    gradIVF.primitiveFieldRef().replace(8,tField);
        
    
    //processor & coupled boundaries
    forAll(mesh_.boundary(), ipatch)
    {
            bool notConstrain = true;

                    if
            (
              isA<emptyFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<wedgeFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<coupledFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryPlaneFvPatch> (mesh_.boundaryMesh()[ipatch])
            )
            {
              notConstrain = false;
            }

            if(notConstrain)
            {
                gradIVF.boundaryFieldRef()[ipatch] = iVF.boundaryField()[ipatch].snGrad()*mesh_.Sf().boundaryField()[ipatch]/mesh_.magSf().boundaryField()[ipatch];
    
        }
    }

    return tgradIVF;
};

tmp<surfaceTensorField> Foam::extendedFaceStencil::faceVectorGrad(const tmp<volVectorField>& tiVF, const tmp<surfaceVectorField>& tsVF)
{
    return faceVectorGrad(tiVF(),tsVF());
}

//- Calculate divergence of volume vector field on the faces.
//
// \param iVF        Internal vector field.
//                   Allowable values: constant reference to the volVectorField.
//
// \return           Divergence of iVF (scalar field) which was computed on the faces of mesh.
tmp<surfaceScalarField> Foam::extendedFaceStencil::faceVectorDiv(const volVectorField& iVF)
{
    surfaceVectorField sVF = linearInterpolate(iVF);
    
    scalarField tField(sVF.primitiveField().size());

    tmp<surfaceScalarField> tdivIVF(0*fvc::snGrad(iVF) & mesh_.Sf() / mesh_.magSf());
    surfaceScalarField& divIVF = tdivIVF.ref();

   faceScalarDer(sVF.primitiveField().component(0),iVF.primitiveField().component(0),0,tField);
    divIVF.primitiveFieldRef() = tField;

    faceScalarDer(sVF.primitiveField().component(1),iVF.primitiveField().component(1),1,tField);
    divIVF.primitiveFieldRef() += tField;

    faceScalarDer(sVF.primitiveField().component(2),iVF.primitiveField().component(2),2,tField);
    divIVF.primitiveFieldRef() += tField; 

    forAll(mesh_.boundaryMesh(),ipatch)
        {
            bool notConstrain = true;

            if
            (
              isA<emptyFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<wedgeFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<coupledFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryPlaneFvPatch> (mesh_.boundaryMesh()[ipatch])
            )
            {
              notConstrain = false;
            }

            if(notConstrain)
            {
                divIVF.boundaryFieldRef()[ipatch] = iVF.boundaryField()[ipatch].snGrad()&mesh_.Sf().boundaryField()[ipatch]/mesh_.magSf().boundaryField()[ipatch];

        }
    }
    
    return tdivIVF;
};

tmp<surfaceScalarField> Foam::extendedFaceStencil::faceVectorDiv(const tmp<volVectorField>& tiVF)
{
    return faceVectorDiv(tiVF());
}

//- Calculate divergence of volume tensor field on the faces.
//
// \param iTF        Internal tensor field.
//                   Allowable values: constant reference to the volTensorField.
//
// \return           Divergence of iTF (vector field) which was computed on the faces of mesh.
tmp<surfaceVectorField> Foam::extendedFaceStencil::faceTensorDiv(const volTensorField& iTF)
{

    surfaceTensorField sTF = linearInterpolate(iTF);
    scalarField tField(sTF.primitiveField().size(), 0.0); 
    tmp<surfaceVectorField> tdivITF(0*fvc::snGrad(iTF.component(0)) * mesh_.Sf() / mesh_.magSf());
    surfaceVectorField& divITF = tdivITF.ref();
    scalarField divComp(sTF.primitiveField().size(), 0.0);

    faceScalarDer(iTF.primitiveField().component(0),sTF.primitiveField().component(0),0,tField);
    divComp = tField;
    faceScalarDer(iTF.primitiveField().component(1),sTF.primitiveField().component(1),1,tField);
    divComp += tField;
    faceScalarDer(iTF.primitiveField().component(2),sTF.primitiveField().component(2),2,tField);
    divComp += tField; 
    divITF.primitiveFieldRef().replace(0,divComp);

    faceScalarDer(iTF.primitiveField().component(3),sTF.primitiveField().component(3),0,tField);
    divComp = tField;
    faceScalarDer(iTF.primitiveField().component(4),sTF.primitiveField().component(4),1,tField);
    divComp += tField;
    faceScalarDer(iTF.primitiveField().component(5),sTF.primitiveField().component(5),2,tField);
    divComp += tField; 
    divITF.primitiveFieldRef().replace(1,divComp);

    faceScalarDer(iTF.primitiveField().component(6),sTF.primitiveField().component(6),0,tField);
    divComp = tField;
    faceScalarDer(iTF.primitiveField().component(7),sTF.primitiveField().component(7),1,tField);
    divComp += tField;
    faceScalarDer(iTF.primitiveField().component(8),sTF.primitiveField().component(8),2,tField);
    divComp += tField;
    divITF.primitiveFieldRef().replace(2,divComp);
    
    forAll(mesh_.boundaryMesh(),ipatch)
        {
            bool notConstrain = true;

            if
          
            (
              isA<emptyFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<wedgeFvPatch> (mesh_.boundaryMesh()[ipatch])||
              isA<coupledFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryFvPatch> (mesh_.boundaryMesh()[ipatch])
        ||
              isA<symmetryPlaneFvPatch> (mesh_.boundaryMesh()[ipatch])
            )
            {
              notConstrain = false;
            }
            if (notConstrain)
            {
                divITF.boundaryFieldRef()[ipatch] = iTF.boundaryField()[ipatch].snGrad()&mesh_.Sf().boundaryField()[ipatch]/mesh_.magSf().boundaryField()[ipatch];
            }
    }


    
    return tdivITF;
}

tmp<surfaceVectorField> Foam::extendedFaceStencil::faceTensorDiv(const tmp<volTensorField>& tiTF)
{
    return faceTensorDiv(tiTF());
}
//
//END-OF-FILE
//


