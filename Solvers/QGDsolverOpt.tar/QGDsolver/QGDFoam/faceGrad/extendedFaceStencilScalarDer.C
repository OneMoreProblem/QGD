#include "extendedFaceStencil.H"
#include "polyMesh.H"
#include "fvMesh.H"
#include "word.H"
#include "IOstream.H"
#include "Ostream.H"
#include <HashTable.H>


//- Calculate gradient of volume scalar function on the faces
//
// \param iF         Internal scalar field.
//                   Allowable values: constant reference to the volScalarField.
//
// \return           Derivative of iF (scalar field) which was computed on the faces of mesh.
void Foam::extendedFaceStencil::faceScalarDer(const Field<scalar>& iF,const Field<scalar>& sF,int com, scalarField& tField)
{
//    tmp<surfaceScalarField> tderIF = 0.0 * mesh_.Sf().component(com) / mesh_.magSf();
//    surfaceScalarField& derIF = tderIF.ref();
    forAll(sF, facei)
    {
        tField[facei] = 0.0;
        forAll(GdfAll_[facei], i)
        {
            tField[facei] += GdfAll_[facei][i].component(com)*(iF[neighbourCells_[facei][i]] - sF[facei]);
        }
    }
}; 

void Foam::extendedFaceStencil::faceScalarDer(const tmp<Field<scalar>>& tiF,const tmp<Field<scalar>>& tsF, int com, tmp<scalarField>& tField )
{
}


//
//END-OF-FILE
//


